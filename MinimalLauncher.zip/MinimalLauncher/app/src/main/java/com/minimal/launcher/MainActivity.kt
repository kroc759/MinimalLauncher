package com.minimal.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.minimal.launcher.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var appAdapter: FavoriteAppAdapter
    private val handler = Handler(Looper.getMainLooper())

    // Saat yeniləmə runnable
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 1000)
        }
    }

    // Tarix dəyişikliyi qəbuledicisi
    private val dateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateDate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Tam ekran - status bar şəffaf
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupFavoriteApps()
        setupClickListeners()
        registerDateReceiver()
    }

    override fun onResume() {
        super.onResume()
        handler.post(clockRunnable)
        updateDate()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(dateReceiver) } catch (e: Exception) {}
    }

    private fun setupFavoriteApps() {
        // Ən çox istifadə olunan tətbiqlər (package adları ilə)
        val favoritePackages = listOf(
            "com.android.dialer",
            "com.android.contacts",
            "com.google.android.apps.messaging",
            "com.google.android.gm",
            "com.google.android.apps.photos",
            "com.google.android.youtube",
            "com.android.settings",
            "com.google.android.apps.maps"
        )

        appAdapter = FavoriteAppAdapter(this, favoritePackages)
        binding.rvFavoriteApps.apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = appAdapter
        }
    }

    private fun setupClickListeners() {
        // Bütün tətbiqlər siyahısını aç
        binding.btnAllApps.setOnClickListener {
            val intent = Intent(this, AppDrawerActivity::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_up, R.anim.fade_out)
        }

        // Axtarış paneli - Google axtarışını aç
        binding.layoutSearch.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_WEB_SEARCH)
                intent.putExtra("query", "")
                startActivity(intent)
            } catch (e: Exception) {
                val intent = packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
                intent?.let { startActivity(it) }
            }
        }
    }

    private fun updateClock() {
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        binding.tvTime.text = timeFormat.format(Date())
    }

    private fun updateDate() {
        val dateFormat = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault())
        binding.tvDate.text = dateFormat.format(Date())
    }

    private fun registerDateReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_TIME_CHANGED)
        }
        registerReceiver(dateReceiver, filter)
    }

    // Geri düyməsi launcher-dən çıxmasın
    override fun onBackPressed() {
        // Heç nə etmə
    }
}
