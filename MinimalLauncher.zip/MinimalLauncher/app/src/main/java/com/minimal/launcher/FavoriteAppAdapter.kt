package com.minimal.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(
    val name: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable?
)

class FavoriteAppAdapter(
    private val context: Context,
    private val packageNames: List<String>
) : RecyclerView.Adapter<FavoriteAppAdapter.AppViewHolder>() {

    private val apps: List<AppInfo> = loadApps()

    private fun loadApps(): List<AppInfo> {
        val pm = context.packageManager
        return packageNames.mapNotNull { pkg ->
            try {
                val info = pm.getApplicationInfo(pkg, 0)
                AppInfo(
                    name = pm.getApplicationLabel(info).toString(),
                    packageName = pkg,
                    icon = pm.getApplicationIcon(pkg)
                )
            } catch (e: PackageManager.NameNotFoundException) {
                null
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val app = apps[position]
        holder.bind(app)
    }

    override fun getItemCount() = apps.size

    inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivIcon: ImageView = itemView.findViewById(R.id.iv_app_icon)
        private val tvName: TextView = itemView.findViewById(R.id.tv_app_name)

        fun bind(app: AppInfo) {
            ivIcon.setImageDrawable(app.icon)
            tvName.text = app.name

            itemView.setOnClickListener {
                val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                intent?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(it)
                }
            }
        }
    }
}
