# 🚀 Minimal Launcher

Minimalist, gözəl Android launcher — qaranlıq tema, böyük saat, sevimli tətbiqlər.

---

## 📱 Xüsusiyyətlər
- Böyük saat + tarix ekranda
- 4x2 sevimli tətbiqlər grid
- Axtarış paneli
- Bütün tətbiqlər siyahısı (axtarışla)
- Tam qaranlıq, minimalist dizayn
- Hamar animasiyalar

---

## 🛠️ APK Yarat — Addım-addım

### 1. Android Studio yüklə
👉 https://developer.android.com/studio (pulsuz)

### 2. Layihəni aç
- Android Studio-nu aç
- **"Open"** düyməsinə bas
- Bu `MinimalLauncher` qovluğunu seç

### 3. Gradle sync gözlə
- Android Studio avtomatik olaraq lazımi faylları yükləyəcək
- Alt hissədə "Gradle sync" tamamlanana qədər gözlə (~2-3 dəq)

### 4. APK yarat
- Yuxarı menyudan: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- Tamamlandıqda bildiriş gəlir: **"locate"** düyməsinə bas
- APK: `app/build/outputs/apk/debug/app-debug.apk`

### 5. Telefona qur
- APK faylını telefona köçür (USB və ya Telegram özünə göndər)
- Telefonda: **Parametrlər → Təhlükəsizlik → Naməlum mənbələr** — AÇ
- APK faylını tap və qur
- Telefon soruşanda **"Minimal Launcher"** seç → **"Həmişə"**

---

## 🎨 Rəng dəyişdirmək istəsən
`app/src/main/res/values/colors.xml` faylını aç:
- `bg_dark` — arxa fon rəngi
- `accent` — vurğu rəngi (indiki: bənövşəyi)
- `text_secondary` — ikinci dərəcəli mətn

## 📱 Sevimli tətbiqləri dəyişmək
`MainActivity.kt` faylında `favoritePackages` siyahısını redaktə et.
Tətbiqin package adını tapmaq üçün Play Store linkindəki `id=...` hissəsinə bax.

---

Uğurlar! 🎉
